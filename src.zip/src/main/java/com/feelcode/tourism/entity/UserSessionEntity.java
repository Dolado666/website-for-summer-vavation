package com.feelcode.tourism.entity;


import lombok.Data;

/**
 * @Author: 朱利尔
 * @Description:
 * @Date: Created in 23:27 2020/5/9
 * @Modified By:
 */
@Data
public class UserSessionEntity {
    private String userName;
}
