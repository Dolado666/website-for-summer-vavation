var base_url='http://localhost:8080/s';
//var base_url='http://www.feelcode.cn:8080/s';

var back_base_url='http://localhost:8082/';
//var back_base_url='http://www.feelcode.cn:8082/';

var file_upload_url='http://localhost:8081/uploadByMap';
//var file_upload_url='http://www.feelcode.cn:8081/uploadByMap';

var file_view_url='http://localhost:8081/';
//var file_view_url='http://www.feelcode.cn:8081/';