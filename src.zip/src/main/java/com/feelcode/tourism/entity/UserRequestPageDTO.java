package com.feelcode.tourism.entity;

import lombok.Data;

@Data
public class UserRequestPageDTO extends CommonRequestPageDTO{

}
