package com.feelcode.tourism.entity;

import lombok.Data;

/**
 * @Author: 朱利尔
 * @Description:
 * @Date: Created in 16:38 2020/6/5
 * @Modified By:
 */
@Data
public class IndexRequestDTO {
}
